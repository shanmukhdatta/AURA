"""AURA External Validation Package."""
